const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const urlencodedParser = bodyParser.urlencoded({ extended: false });
const mongodb = require('../database/dbOperations');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index.ejs');
});

/* GET Raise Complaints page. */
router.get('/raise', function(req, res, next) {
  res.render('raise-complaints.ejs');
});

/* GET List Of Complaints page. */
router.get('/list', function(req, res, next) {
  // get database connection Object
  let db = mongodb.getDB();
  // get the complaints information from the database
  db.collection('complaints').find().toArray((err , complaintsList) => {
    res.render('list-of-complaints.ejs' , {complaintsList : complaintsList});
  });
});

/* POSt Raise Complaints Form page. */
router.post('/complain', urlencodedParser, function(req, res, next) {
  let complaintInfo = req.body;

  // get the db connection Object
  let db = mongodb.getDB();
  // insert the form data to database
  db.collection('complaints').insertOne(complaintInfo , (err , r) => {
    console.log('Complaint is inserted to Database');
    res.render('raise-complaints-success.ejs' , { complaintInfo : complaintInfo});
  });
});

module.exports = router;
